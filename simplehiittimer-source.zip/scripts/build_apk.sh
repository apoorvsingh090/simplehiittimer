#!/bin/bash
# Build SimpleHIITTimer.apk without Gradle: aapt2 -> javac -> d8 -> zipalign -> apksigner
set -e

SDK=/home/z/my-project/android-sdk
BT=$SDK/build-tools/34.0.0
AJAR=$SDK/platforms/android-34/android.jar
PROJ=/home/z/my-project/hiit
OUT=$PROJ/build
KS=/home/z/my-project/scripts/hiit.keystore

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/obj" "$OUT/apk"

echo "== aapt2 compile =="
"$BT/aapt2" compile --dir "$PROJ/res" -o "$OUT/res.zip"

echo "== aapt2 link =="
"$BT/aapt2" link -o "$OUT/base.apk" \
    -I "$AJAR" \
    --manifest "$PROJ/AndroidManifest.xml" \
    --java "$OUT/gen" \
    --min-sdk-version 24 \
    --target-sdk-version 34 \
    --version-code 1 \
    --version-name 1.0 \
    "$OUT/res.zip"

echo "== ecj =="
find "$OUT/gen" "$PROJ/java" -name "*.java" > "$OUT/sources.txt"
java -jar /home/z/my-project/scripts/ecj.jar -source 8 -target 8 -nowarn \
    -bootclasspath "$AJAR" -classpath "$OUT/gen:$BT/core-lambda-stubs.jar" \
    -d "$OUT/obj" @"$OUT/sources.txt"
find "$OUT/obj" -name "*.class" | head -20

echo "== d8 =="
find "$OUT/obj" -name "*.class" > "$OUT/classes.txt"
"$BT/d8" --release --lib "$AJAR" --min-api 24 --output "$OUT/apk" $(cat "$OUT/classes.txt")

echo "== package =="
cp "$OUT/base.apk" "$OUT/app.apk"
(cd "$OUT/apk" && zip -q -u "$OUT/app.apk" classes.dex)
"$BT/zipalign" -f -p 4 "$OUT/app.apk" "$OUT/aligned.apk"

echo "== sign =="
if [ ! -f "$KS" ]; then
    keytool -genkeypair -keystore "$KS" -alias hiit -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass android -keypass android -dname "CN=Simple HIIT Timer, O=SimpleHIIT"
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
    --out /home/z/my-project/download/SimpleHIITTimer.apk "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs /home/z/my-project/download/SimpleHIITTimer.apk
echo "== done =="
ls -la /home/z/my-project/download/SimpleHIITTimer.apk
