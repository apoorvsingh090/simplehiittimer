#!/usr/bin/env python3
"""Generate launcher icons (dark gym style: red ring + HIIT) for the APK."""
from PIL import Image, ImageDraw, ImageFont
import os

OUT = "/home/z/my-project/hiit/res"
BG = (11, 11, 16, 255)        # #0B0B10
RED = (255, 68, 56, 255)      # #FF4438
BLUE = (61, 139, 255, 255)    # #3D8BFF
TRACK = (44, 44, 54, 255)
WHITE = (245, 245, 247, 255)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def draw_icon(size, legacy=True):
    S = 4  # supersample for smooth edges
    px = size * S
    img = Image.new("RGBA", (px, px), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if legacy:
        d.rounded_rectangle([0, 0, px - 1, px - 1], radius=int(px * 0.18), fill=BG)
        pad = int(px * 0.09)
    else:
        pad = int(px * 0.225)  # keep inside adaptive-icon safe zone
    box = [pad, pad, px - pad, px - pad]
    w = box[2] - box[0]
    stroke = max(S, int(w * 0.085))
    # full track
    d.arc(box, 0, 360, fill=TRACK, width=stroke)
    # red arc: 270 degrees from top (12 -> 9 o'clock, clockwise)
    d.arc(box, start=-90, end=180, fill=RED, width=stroke)
    # small blue tail suggesting the rest phase
    d.arc(box, start=185, end=215, fill=BLUE, width=stroke)
    # HIIT text
    f = ImageFont.truetype(FONT, int(w * 0.33))
    d.text(((box[0] + box[2]) / 2, (box[1] + box[3]) / 2), "HIIT",
           font=f, fill=WHITE, anchor="mm")
    return img.resize((size, size), Image.LANCZOS)


densities = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
for name, s in densities.items():
    p = os.path.join(OUT, "mipmap-" + name)
    os.makedirs(p, exist_ok=True)
    draw_icon(s, legacy=True).save(os.path.join(p, "ic_launcher.png"))
    print("wrote", p + "/ic_launcher.png")

p = os.path.join(OUT, "drawable-xxxhdpi")
os.makedirs(p, exist_ok=True)
draw_icon(432, legacy=False).save(os.path.join(p, "ic_fg.png"))
print("wrote", p + "/ic_fg.png")
print("done")
