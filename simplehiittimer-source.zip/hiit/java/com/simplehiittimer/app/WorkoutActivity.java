package com.simplehiittimer.app;

import android.app.Activity;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class WorkoutActivity extends Activity {

    private static final int TYPE_PREP = 0, TYPE_WORK = 1, TYPE_REST = 2;

    private static class Seg {
        final int type, seconds, round;

        Seg(int t, int s, int r) {
            type = t;
            seconds = s;
            round = r;
        }
    }

    private final ArrayList<Seg> segs = new ArrayList<>();
    private final Handler handler = new Handler();
    private int idx = -1;
    private long segEnd, segTotalMs, totalEnd, totalMs;
    private long pausedAt;
    private boolean paused, finished, sound = true;
    private int lastBeepSec = -1;
    private int curColor, roundsTotal;
    private String phaseWord = "";
    private ToneGenerator tone;

    private RingView ring;
    private TextView tvPhase, tvTime, tvRound, tvTotal, tvHint;
    private int colPrep, colWork, colRest, colDone, colPaused;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (paused || finished) return;
            long now = SystemClock.elapsedRealtime();
            long remainMs = segEnd - now;
            if (remainMs <= 0) {
                startNext();
                return;
            }
            int secLeft = (int) Math.ceil(remainMs / 1000.0);
            if (sound && tone != null && secLeft <= 3 && secLeft >= 1 && secLeft != lastBeepSec) {
                lastBeepSec = secLeft;
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 140);
            }
            ring.setProgress((float) remainMs / (float) segTotalMs);
            setTime(fmt(secLeft));
            long tr = totalEnd - now;
            tvTotal.setText(getString(R.string.total) + " " + fmt((int) Math.max(0, Math.ceil(tr / 1000.0))));
            handler.postDelayed(this, 50);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep the screen awake for the whole workout (no permission needed).
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_workout);

        int work = Math.max(1, getIntent().getIntExtra("work", 30));
        int rest = Math.max(0, getIntent().getIntExtra("rest", 30));
        int rounds = Math.max(1, getIntent().getIntExtra("rounds", 10));
        roundsTotal = rounds;
        boolean prep = getIntent().getBooleanExtra("prep", true);
        sound = getIntent().getBooleanExtra("sound", true);

        colPrep = getColor(R.color.yellow);
        colWork = getColor(R.color.red);
        colRest = getColor(R.color.blue);
        colDone = getColor(R.color.green);
        colPaused = 0xFF4A4A55;

        if (prep) segs.add(new Seg(TYPE_PREP, 5, 0));
        for (int r = 1; r <= rounds; r++) {
            segs.add(new Seg(TYPE_WORK, work, r));
            if (r < rounds) segs.add(new Seg(TYPE_REST, rest, r));
        }
        totalMs = 0;
        for (Seg s : segs) totalMs += s.seconds * 1000L;
        totalEnd = SystemClock.elapsedRealtime() + totalMs;

        ring = (RingView) findViewById(R.id.ring);
        tvPhase = (TextView) findViewById(R.id.tv_phase);
        tvTime = (TextView) findViewById(R.id.tv_time);
        tvRound = (TextView) findViewById(R.id.tv_round);
        tvTotal = (TextView) findViewById(R.id.tv_total);
        tvHint = (TextView) findViewById(R.id.tv_hint);
        tvTotal.setText(getString(R.string.total) + " " + fmt((int) (totalMs / 1000)));

        findViewById(R.id.btn_end).setOnClickListener(v -> finish());
        findViewById(R.id.root).setOnClickListener(v -> tap());

        tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        startNext();
    }

    private void startNext() {
        idx++;
        if (idx >= segs.size()) {
            onDone();
            return;
        }
        Seg s = segs.get(idx);
        long now = SystemClock.elapsedRealtime();
        segTotalMs = s.seconds * 1000L;
        segEnd = now + segTotalMs;
        lastBeepSec = s.seconds + 1;

        switch (s.type) {
            case TYPE_PREP:
                phaseWord = getString(R.string.phase_prep);
                curColor = colPrep;
                break;
            case TYPE_WORK:
                phaseWord = getString(R.string.phase_work);
                curColor = colWork;
                break;
            default:
                phaseWord = getString(R.string.phase_rest);
                curColor = colRest;
                break;
        }
        if (s.type == TYPE_PREP) {
            tvRound.setText("");
        } else {
            tvRound.setText(getString(R.string.round) + " " + s.round + " / " + roundsTotal);
        }

        tvPhase.setText(phaseWord);
        tvPhase.setTextColor(curColor);
        tvTime.setTextColor(curColor);
        ring.setColor(curColor);
        ring.setProgress(1f);
        setTime(fmt(s.seconds));

        if (sound && tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 450);

        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void tap() {
        if (finished) {
            finish();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (!paused) {
            paused = true;
            pausedAt = now;
            handler.removeCallbacks(tick);
            tvPhase.setText(getString(R.string.paused));
            tvPhase.setTextColor(colPaused);
            ring.setColor(colPaused);
            tvHint.setText(R.string.hint_resume);
        } else {
            long d = now - pausedAt;
            segEnd += d;
            totalEnd += d;
            paused = false;
            tvPhase.setText(phaseWord);
            tvPhase.setTextColor(curColor);
            ring.setColor(curColor);
            tvHint.setText(R.string.hint_pause);
            handler.removeCallbacks(tick);
            handler.post(tick);
        }
    }

    private void onDone() {
        finished = true;
        handler.removeCallbacks(tick);
        ring.setProgress(1f);
        ring.setColor(colDone);
        tvPhase.setText(getString(R.string.phase_done));
        tvPhase.setTextColor(colDone);
        tvTime.setTextColor(colDone);
        setTime(fmt((int) (totalMs / 1000)));
        tvRound.setText(roundsTotal + " " + getString(R.string.rounds_complete));
        tvTotal.setText(getString(R.string.total) + " 0:00");
        tvHint.setText(R.string.hint_finish);
        if (sound && tone != null) {
            tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 300);
            handler.postDelayed(() -> {
                if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 300);
            }, 320);
            handler.postDelayed(() -> {
                if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 600);
            }, 640);
        }
    }

    private void setTime(String s) {
        tvTime.setText(s);
        int n = s.length();
        if (n <= 4) tvTime.setTextSize(84);
        else if (n <= 7) tvTime.setTextSize(56);
        else tvTime.setTextSize(44);
    }

    private static String fmt(int t) {
        if (t >= 3600) {
            return String.format(Locale.US, "%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60);
        }
        if (t >= 60) {
            return String.format(Locale.US, "%d:%02d", t / 60, t % 60);
        }
        return String.valueOf(t);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (tone != null) {
            tone.release();
            tone = null;
        }
    }
}
