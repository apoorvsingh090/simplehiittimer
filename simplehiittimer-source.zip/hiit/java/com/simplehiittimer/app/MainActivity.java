package com.simplehiittimer.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends Activity {

    private static final String PREFS = "hiit_prefs";

    private static final int[][] PRESETS = {
            {20, 10, 8}, {30, 30, 10}, {40, 20, 8},
            {60, 60, 10}, {60, 120, 8}, {15, 45, 10}
    };
    private static final String[] PRESET_LABELS = {
            "Tabata 20/10", "30s / 30s", "40s / 20s",
            "1m / 1m", "Run 1m/2m", "Sprint 15/45"
    };

    private int work = 30, rest = 30, rounds = 10;
    private boolean prep = true, sound = true;

    private TextView tvWork, tvRest, tvRounds;
    private LinearLayout presetsRow;
    private SharedPreferences prefs;
    private final Handler handler = new Handler();
    private final HashMap<View, Runnable> repeaters = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        work = prefs.getInt("work", 30);
        rest = prefs.getInt("rest", 30);
        rounds = prefs.getInt("rounds", 10);
        prep = prefs.getBoolean("prep", true);
        sound = prefs.getBoolean("sound", true);

        tvWork = (TextView) findViewById(R.id.tv_work);
        tvRest = (TextView) findViewById(R.id.tv_rest);
        tvRounds = (TextView) findViewById(R.id.tv_rounds);

        Switch swPrep = (Switch) findViewById(R.id.sw_prep);
        Switch swSound = (Switch) findViewById(R.id.sw_sound);
        swPrep.setChecked(prep);
        swSound.setChecked(sound);
        swPrep.setOnCheckedChangeListener((b, v) -> {
            prep = v;
            savePrefs();
        });
        swSound.setOnCheckedChangeListener((b, v) -> {
            sound = v;
            savePrefs();
        });

        bindRepeat(findViewById(R.id.btn_work_minus), () -> changeWork(-5));
        bindRepeat(findViewById(R.id.btn_work_plus), () -> changeWork(5));
        bindRepeat(findViewById(R.id.btn_rest_minus), () -> changeRest(-5));
        bindRepeat(findViewById(R.id.btn_rest_plus), () -> changeRest(5));
        bindRepeat(findViewById(R.id.btn_rounds_minus), () -> changeRounds(-1));
        bindRepeat(findViewById(R.id.btn_rounds_plus), () -> changeRounds(1));

        presetsRow = (LinearLayout) findViewById(R.id.presets_row);
        buildPresets();

        findViewById(R.id.btn_start).setOnClickListener(v -> {
            savePrefs();
            Intent it = new Intent(this, WorkoutActivity.class);
            it.putExtra("work", work);
            it.putExtra("rest", rest);
            it.putExtra("rounds", rounds);
            it.putExtra("prep", prep);
            it.putExtra("sound", sound);
            startActivity(it);
        });

        findViewById(R.id.btn_guide).setOnClickListener(v ->
                startActivity(new Intent(this, GuideActivity.class)));

        updateValues();
    }

    private void buildPresets() {
        for (int i = 0; i < PRESETS.length; i++) {
            final int idx = i;
            TextView chip = new TextView(this);
            chip.setText(PRESET_LABELS[i]);
            chip.setTextSize(13);
            chip.setLetterSpacing(0.05f);
            chip.setBackgroundResource(R.drawable.chip_bg);
            chip.setTextColor(getResources().getColorStateList(R.color.chip_text));
            chip.setPadding(dp(16), dp(10), dp(16), dp(10));
            chip.setClickable(true);
            chip.setOnClickListener(v -> applyPreset(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            presetsRow.addView(chip, lp);
        }
        markSelected();
    }

    private void applyPreset(int i) {
        work = PRESETS[i][0];
        rest = PRESETS[i][1];
        rounds = PRESETS[i][2];
        updateValues();
        markSelected();
        savePrefs();
    }

    private void markSelected() {
        for (int i = 0; i < PRESETS.length; i++) {
            boolean m = work == PRESETS[i][0] && rest == PRESETS[i][1] && rounds == PRESETS[i][2];
            presetsRow.getChildAt(i).setSelected(m);
        }
    }

    private void changeWork(int d) {
        work = clamp(work + d, 0, 999);
        updateValues();
        markSelected();
        savePrefs();
    }

    private void changeRest(int d) {
        rest = clamp(rest + d, 0, 999);
        updateValues();
        markSelected();
        savePrefs();
    }

    private void changeRounds(int d) {
        rounds = clamp(rounds + d, 1, 50);
        updateValues();
        markSelected();
        savePrefs();
    }

    private void updateValues() {
        tvWork.setText(String.valueOf(work));
        tvRest.setText(String.valueOf(rest));
        tvRounds.setText(String.valueOf(rounds));
    }

    private void savePrefs() {
        prefs.edit()
                .putInt("work", work)
                .putInt("rest", rest)
                .putInt("rounds", rounds)
                .putBoolean("prep", prep)
                .putBoolean("sound", sound)
                .apply();
    }

    /** Click fires the action; press-and-hold repeats it every 70 ms after 450 ms. */
    private void bindRepeat(final View v, final Runnable action) {
        v.setOnTouchListener((view, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    action.run();
                    Runnable r = new Runnable() {
                        @Override
                        public void run() {
                            action.run();
                            handler.postDelayed(this, 70);
                        }
                    };
                    repeaters.put(v, r);
                    handler.postDelayed(r, 450);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    Runnable old = repeaters.remove(v);
                    if (old != null) handler.removeCallbacks(old);
                    return true;
            }
            return false;
        });
    }

    private static int clamp(int v, int min, int max) {
        return v < min ? min : (v > max ? max : v);
    }

    private int dp(float v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }
}
