package com.simplehiittimer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Progress ring that drains clockwise; color tracks the current phase. */
public class RingView extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float progress = 1f;
    private int color = 0xFFFF4438;

    public RingView(Context c) {
        this(c, null);
    }

    public RingView(Context c, AttributeSet attrs) {
        super(c, attrs);
        track.setStyle(Paint.Style.STROKE);
        track.setColor(0xFF23232C);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
    }

    /** @param p fraction remaining, 0..1 */
    public void setProgress(float p) {
        progress = Math.max(0f, Math.min(1f, p));
        invalidate();
    }

    public void setColor(int c) {
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float stroke = Math.min(getWidth(), getHeight()) * 0.055f;
        float pad = stroke / 2f + 2f;
        rect.set(pad, pad, getWidth() - pad, getHeight() - pad);
        track.setStrokeWidth(stroke);
        arc.setStrokeWidth(stroke);
        arc.setColor(color);
        canvas.drawArc(rect, 0, 360, false, track);
        if (progress > 0f) {
            canvas.drawArc(rect, -90f, 360f * progress, false, arc);
        }
    }
}
